import { useEffect, useState } from 'react'

type IconName = 'arrow' | 'check' | 'clock' | 'location' | 'menu' | 'phone' | 'sparkle' | 'whatsapp' | 'x'

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    location: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    phone: <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.4 2.1L8.1 10a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c1 .3 1.9.6 2.9.7a2 2 0 0 1 1.6 1.9Z"/>,
    sparkle: <path d="m12 3 1.4 4.4L18 9l-4.6 1.6L12 15l-1.4-4.4L6 9l4.6-1.6L12 3ZM19 15l.7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7L19 15Z"/>,
    whatsapp: <><path d="M21 11.5a8.8 8.8 0 0 1-13 7.7L3 21l1.7-4.8A8.8 8.8 0 1 1 21 11.5Z"/><path d="M8.5 8.2c.5 3 2.3 4.8 5.3 5.3"/></>,
    x: <><path d="m6 6 12 12M18 6 6 18"/></>,
  }
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>
}

const services = [
  { name: 'Advanced Skin Treatments', tag: 'Skin ritual', image: '/assets/skin-studio.jpg', text: 'Technology-led care tailored to your skin goals.' },
  { name: 'Hair Treatments', tag: 'Hair science', image: '/assets/hair-care.jpg', text: 'Restorative rituals for stronger, luminous hair.' },
  { name: 'Hydra & Korean Facial', tag: 'Glass skin', image: '/assets/salon-interior.jpg', text: 'Deep hydration and signature Korean glow protocols.' },
  { name: 'Nails & Self-care', tag: 'Detail', image: '/assets/nail-care.jpg', text: 'Impeccable nail care in a serene private setting.' },
  { name: 'Hair Styling', tag: 'Style', image: '/assets/hair-lounge.jpg', text: 'Precision cuts, colour and styling for every identity.' },
  { name: 'Makeup & Bridal', tag: 'Occasion', image: '/assets/skin-studio.jpg', text: 'Camera-ready artistry for your most memorable moments.' },
]

const rituals = [
  { number: '01', title: 'We listen', text: 'Every visit begins with an unrushed consultation to understand your style, routine and goals.' },
  { number: '02', title: 'We personalise', text: 'Our experts design a considered service using techniques and products selected especially for you.' },
  { number: '03', title: 'We elevate', text: 'Leave with a result that looks beautiful, feels effortless and remains unmistakably yours.' },
]

const faqs = [
  ['Do I need an appointment?', 'Appointments are recommended so we can reserve the right specialist and time for you. Call or WhatsApp us for the quickest booking.'],
  ['Are your services for everyone?', 'Yes. Aura Elevate is a welcoming unisex salon with personalised hair, beauty, skin and grooming services.'],
  ['How do I know which skin treatment is right for me?', 'Your specialist will begin with a consultation and recommend a treatment suited to your skin, concerns and desired results.'],
  ['Do you offer bridal packages?', 'Yes. We offer personalised bridal hair, makeup, skin and nail experiences. Contact our team to create your plan.'],
  ['Which areas do you serve?', 'Our Kiwale studio is conveniently located for guests from Ravet, Punawale and across Pimpri-Chinchwad.'],
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const closeMenu = () => setMenuOpen(false)

  return (
    <main>
      <header className={`site-header ${scrolled ? 'scrolled' : ''}`}>
        <a className="brand" href="#home" aria-label="Aura Elevate Studios home">
          <img src="/assets/aura-logo.jpg" alt="" />
          <span>AURA <small>ELEVATE STUDIOS</small></span>
        </a>
        <nav className={menuOpen ? 'open' : ''} aria-label="Main navigation">
          <a href="#services" onClick={closeMenu}>Services</a>
          <a href="#experience" onClick={closeMenu}>Our studio</a>
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#contact" onClick={closeMenu}>Contact</a>
          <a className="nav-book" href="tel:+917066729214" onClick={closeMenu}>Book a visit <Icon name="arrow" size={16} /></a>
        </nav>
        <button className="menu-button" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label="Toggle navigation">
          <Icon name={menuOpen ? 'x' : 'menu'} />
        </button>
      </header>

      <section className="hero" id="home">
        <img className="hero-bg" src="/assets/salon-interior.jpg" alt="Elegant interior of Aura Elevate Studios in Kiwale" />
        <div className="hero-shade" />
        <div className="orb orb-one" /><div className="orb orb-two" />
        <div className="hero-content">
          <p className="eyebrow"><Icon name="sparkle" size={15} /> Premium unisex salon & skin studio</p>
          <h1>Let your <em>aura</em><br />speak first.</h1>
          <p className="hero-copy">Modern artistry, advanced skin rituals and deeply personal care—crafted for the way you want to feel.</p>
          <div className="hero-actions">
            <a className="button primary" href="tel:+917066729214">Book an appointment <Icon name="arrow" /></a>
            <a className="button glass" href="#services">Explore services</a>
          </div>
          <div className="hero-meta">
            <span><Icon name="location" size={17} /> Kiwale, Pune</span>
            <span><Icon name="clock" size={17} /> Open all week</span>
          </div>
        </div>
        <div className="hero-seal" aria-hidden="true"><span>BEAUTY · WELLNESS · AURA · </span><Icon name="sparkle" size={28} /></div>
        <a className="scroll-cue" href="#services" aria-label="Scroll to services"><span>SCROLL TO DISCOVER</span><i /></a>
      </section>

      <div className="marquee" aria-label="Aura Elevate services">
        <div>
          <span>HAIR ARTISTRY</span><i>✦</i><span>ADVANCED SKIN</span><i>✦</i><span>KOREAN FACIALS</span><i>✦</i><span>NAIL RITUALS</span><i>✦</i><span>BRIDAL BEAUTY</span><i>✦</i>
          <span>HAIR ARTISTRY</span><i>✦</i><span>ADVANCED SKIN</span><i>✦</i><span>KOREAN FACIALS</span><i>✦</i><span>NAIL RITUALS</span><i>✦</i><span>BRIDAL BEAUTY</span><i>✦</i>
        </div>
      </div>

      <section className="services section" id="services">
        <div className="section-heading reveal">
          <div><p className="eyebrow dark">Our expertise</p><h2>Care, elevated to an <em>art form.</em></h2></div>
          <p>From precision hair artistry to advanced skin technology, every service is thoughtfully personalised by our specialists.</p>
        </div>
        <div className="service-grid">
          {services.map((service, index) => (
            <article className="service-card" key={service.name}>
              <img src={service.image} alt={`${service.name} at Aura Elevate Studios`} loading={index > 2 ? 'lazy' : 'eager'} />
              <div className="service-overlay" />
              <div className="service-top"><span>0{index + 1}</span><span>{service.tag}</span></div>
              <div className="service-bottom">
                <h3>{service.name}</h3><p>{service.text}</p>
                <a href={`https://wa.me/917066729214?text=${encodeURIComponent(`Hi Aura Elevate, I'd like to know about ${service.name}.`)}`} target="_blank" rel="noreferrer" aria-label={`Enquire about ${service.name}`}><Icon name="arrow" /></a>
              </div>
            </article>
          ))}
        </div>
        <p className="price-note"><Icon name="sparkle" size={16} /> Every experience is personalised. Contact our team for a consultation and current pricing.</p>
      </section>

      <section className="manifesto section">
        <div className="manifesto-copy">
          <span className="giant-mark">A</span>
          <p className="eyebrow dark">The art of becoming</p>
          <h2>Not a new you.<br />A more radiant <em>you.</em></h2>
          <p>Beauty should never feel generic. At Aura, every detail—from the first conversation to the final reveal—is shaped around your individuality. We combine artistry with technology to create results that feel as good as they look.</p>
          <a className="text-link dark-link" href="#contact">Begin your Aura journey <Icon name="arrow" /></a>
        </div>
        <div className="manifesto-gallery">
          <figure className="portrait-one"><img src="/assets/nail-care.jpg" alt="Relaxing nail care experience at Aura Elevate" loading="lazy" /><figcaption>Quiet luxury<br /><span>Nail & self-care</span></figcaption></figure>
          <figure className="portrait-two"><img src="/assets/hair-care.jpg" alt="Professional hair care at Aura Elevate" loading="lazy" /><figcaption>Expert hands<br /><span>Hair rituals</span></figcaption></figure>
          <div className="glass-quote"><Icon name="sparkle" /><span>Created around<br />your unique aura</span></div>
        </div>
      </section>

      <section className="experience section" id="experience">
        <div className="experience-visual">
          <video autoPlay muted loop playsInline poster="/assets/hair-lounge.jpg" aria-label="Inside Aura Elevate Studios">
            <source src="/assets/aura-experience.mp4" type="video/mp4" />
          </video>
          <div className="floating-note"><strong>AURA</strong><span>A calm world, created for you.</span></div>
        </div>
        <div className="experience-copy" id="about">
          <p className="eyebrow dark">The Aura experience</p>
          <h2>Luxury you can <em>feel.</em><br />Care you can trust.</h2>
          <p>Aura Elevate is more than a salon. It is your pause from the everyday—a serene destination where skilled professionals blend modern techniques, advanced machinery and considered care.</p>
          <ul>
            <li><Icon name="check" /> Experienced hair & beauty professionals</li>
            <li><Icon name="check" /> Advanced technology & premium products</li>
            <li><Icon name="check" /> Personalised consultation for every guest</li>
            <li><Icon name="check" /> Elegant, hygienic & welcoming studio</li>
          </ul>
          <a className="text-link" href="tel:+917066729214">Speak to our team <Icon name="arrow" /></a>
        </div>
      </section>

      <section className="ritual section">
        <div className="ritual-heading">
          <p className="eyebrow dark">Your journey</p>
          <h2>Thoughtful from hello<br />to the final <em>reveal.</em></h2>
        </div>
        <div className="ritual-list">
          {rituals.map((ritual) => (
            <article key={ritual.number}>
              <span>{ritual.number}</span>
              <div><h3>{ritual.title}</h3><p>{ritual.text}</p></div>
              <Icon name="sparkle" size={24} />
            </article>
          ))}
        </div>
      </section>

      <section className="feature-band">
        <div><strong>One studio.</strong><span>Complete care.</span></div>
        <div className="feature-stats">
          <p><b>Hair</b><small>Cut · Colour · Care</small></p>
          <p><b>Skin</b><small>Facials · Advanced rituals</small></p>
          <p><b>Beauty</b><small>Nails · Makeup · Bridal</small></p>
        </div>
      </section>

      <section className="areas section">
        <p className="eyebrow dark">Close to you</p>
        <h2>Your new beauty destination in <em>Pune.</em></h2>
        <div className="area-list"><span>Kiwale</span><i /><span>Ravet</span><i /><span>Punawale</span><i /><span>Pimpri-Chinchwad</span></div>
      </section>

      <section className="faq section">
        <div className="faq-intro">
          <p className="eyebrow dark">Good to know</p>
          <h2>Your questions,<br /><em>beautifully answered.</em></h2>
          <p>Need something else? Our team is just a message away.</p>
          <a className="text-link dark-link" href="https://wa.me/917066729214?text=Hi%20Aura%20Elevate%2C%20I%20have%20a%20question." target="_blank" rel="noreferrer">Ask us on WhatsApp <Icon name="arrow" /></a>
        </div>
        <div className="faq-list">
          {faqs.map(([question, answer], index) => (
            <details key={question} open={index === 0}>
              <summary><span>0{index + 1}</span>{question}<b>+</b></summary>
              <p>{answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="contact section" id="contact">
        <div className="contact-card">
          <div className="contact-copy">
            <p className="eyebrow">Your moment awaits</p>
            <h2>Ready to elevate<br />your everyday?</h2>
            <p>Call or message us to reserve your personalised salon experience.</p>
            <div className="contact-actions">
              <a className="button primary" href="tel:+917066729214"><Icon name="phone" /> 70667 29214</a>
              <a className="button glass" href="https://wa.me/917066729214?text=Hi%20Aura%20Elevate%2C%20I'd%20like%20to%20book%20an%20appointment." target="_blank" rel="noreferrer"><Icon name="whatsapp" /> WhatsApp us</a>
            </div>
          </div>
          <address>
            <span><Icon name="location" /></span>
            <div><small>VISIT THE STUDIO</small><strong>A1, Shop 12, Gini Vivante</strong><p>Kiwale, Ravet, Pimpri-Chinchwad,<br />Pune, Maharashtra 412101</p><a href="https://www.google.com/maps/search/?api=1&query=Aura+Elevate+Studios+Gini+Vivante+Kiwale+Pune" target="_blank" rel="noreferrer">Get directions <Icon name="arrow" size={16} /></a></div>
          </address>
        </div>
      </section>

      <footer>
        <a className="brand footer-brand" href="#home"><img src="/assets/aura-logo.jpg" alt="Aura Elevate Studios logo" /><span>AURA <small>ELEVATE STUDIOS</small></span></a>
        <p>Hair · Skin · Nails · Makeup · Wellness</p>
        <div><span>© {new Date().getFullYear()} Aura Elevate Studios</span><a href="tel:+917066729214">70667 29214</a></div>
      </footer>
      <a className="floating-whatsapp" href="https://wa.me/917066729214?text=Hi%20Aura%20Elevate%2C%20I'd%20like%20to%20book%20an%20appointment." target="_blank" rel="noreferrer" aria-label="Book on WhatsApp"><Icon name="whatsapp" /></a>
    </main>
  )
}

export default App
